from time import time

from kodi_six import xbmc, xbmcaddon

from . import userdata, gui, router
from .proxy import Proxy
from .session import Session
from .util import hash_6
from .log import log
from .language import _
from .constants import NEWS_URL, NEWS_CHECK_TIME, NEWS_MAX_TIME

def _check_news():
    _time = int(time())

    if _time < userdata.get('last_news_check', 0) + NEWS_CHECK_TIME:
        return

    userdata.set('last_news_check', _time)

    news = Session().get(NEWS_URL).json()
    if not news:
        return

    if 'id' not in news or news['id'] == userdata.get('last_news_id'):
        return

    userdata.set('last_news_id', news['id'])

    if _time > news.get('timestamp', _time) + NEWS_MAX_TIME:
        log.debug("news is too old to show")
        return

    if news['type'] == 'addon_release':
        try: addon = xbmcaddon.Addon(news['addon_id'])
        except: addon = None

        if addon:
            log.debug("addon_release add-on already installed")
            return

        if gui.yes_no(news['message'], news.get('heading', _.NEWS_HEADING)):
            xbmc.executebuiltin('InstallAddon({})'.format(news['addon_id']), True)
            xbmc.executeJSONRPC('{{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{{"addonid":"{}","enabled":true}}}}'.format(news['addon_id']))

            try: addon = xbmcaddon.Addon(news['addon_id'])
            except: return

            url = router.url_for('', _addon_id=news['addon_id'])
            xbmc.executebuiltin( "ActivateWindow(Videos,{})".format(url))

def start():
    proxy = Proxy()
    proxy.start()

    monitor = xbmc.Monitor()

    try:
        while not monitor.abortRequested():
            try: _check_news()
            except Exception as e:
                log.exception(e)

            if monitor.waitForAbort(10):
                break
    except:
        pass

    proxy.stop()